Thay imei & cookie vào 2 file trong thư mục dataLogin

cd to thư mục chứa main.py chạy: make install && make run 

rảnh support: https://zalo.me/g/mfonid834
phiền t block ;))))
